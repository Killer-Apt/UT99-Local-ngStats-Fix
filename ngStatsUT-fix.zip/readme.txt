Unreal Tournament (1999) Local NGStats Fix (Windows) (Reproduction of original patch from Epic Games)
-------------------------------------------
INSTALLATION: Unzip the contents of ngStatsUT-fix.zip to your Unreal Tournament install directory.
Example (For Steam users): Steam\steamapps\common\Unreal Tournament\...

TO USE: Double click ngStatsUT.exe in the NetGamesUSA\ngstats\ folder to generate an HTML page that displays
current stats for your account. These stats will record automatically as you play and can be loaded with the
game still running in the background.
-------------------------------------------
Help:

[I can't get my stats to load after using the drop down menu in-game.]

This is normal, you may have to tab out of the game and open ngStatsUT.exe in order to generate stats. I
recommend creating a shortcut on your desktop.

[How do I reset my stats?]

Delete all of the files in the NetGamesUSA\ngstats\data\ folder to reset all stats to 0. These files will be
recreated automatically once you play another game.

[I can view the HTML page but it never records.]

This could be a result of improper installation. Double check to make sure there is only one NetGamesUSA folder!
--------------------------------------------
Special thanks to the Reddit community
-Ruckmonster







